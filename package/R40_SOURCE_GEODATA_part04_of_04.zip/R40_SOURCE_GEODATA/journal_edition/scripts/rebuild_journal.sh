#!/usr/bin/env bash
# Rebuild the journal figures from the first-edition package (offline if inputs/rasters/overview_kz is present).
set -euo pipefail
cd "$(dirname "$0")"
python -m pip install -r requirements.txt -r requirements-carto.txt
python -m src.cartography_journal build --package ../R40_CARTOGRAPHY_SOURCE_PACKAGE --out ../journal_rebuild
