#!/usr/bin/env bash
# Rebuild every derived raster, vector, figure and table from the packaged inputs (offline, no network).
set -euo pipefail
cd "$(dirname "$0")"
python -m pip install -r requirements.txt -r requirements-carto.txt
python -m src.cartography build --package .. --out ../rebuild_check
echo 'Compare: diff -r ../tables ../rebuild_check/tables'
