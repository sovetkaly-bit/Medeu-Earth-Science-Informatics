R40_SOURCE_GEODATA: part 3 of 4. Parts are independent zips (no split archive); unzip all into one folder. Each part lists its files with SHA-256 in PART_CONTENTS_*.csv.
